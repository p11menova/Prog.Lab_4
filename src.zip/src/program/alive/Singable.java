package program.alive;


import program.inanimate.DopAction;
import program.sounds.Song;

public interface Singable {
    void changeSong(Song song);

    String singSong();

    String singSong(DopAction dop);

}
