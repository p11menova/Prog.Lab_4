package program.alive;

import program.thoughts.Thought;

public interface Thinkable {
    void addThought(Thought thought);
    String think();

}
