package program;

public class Main {
    public static void main(String[] args) {
        Story story = new Story();
        story.prepare();
        story.go();
    }
}